package com.student.command;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UpdateStudentCommand {
	
	@TargetAggregateIdentifier
	private String studentId;
	private String name;
	private int age;
	private String city;
	public UpdateStudentCommand(String studentId, String name, int age, String city) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.age = age;
		this.city = city;
	}
	
	
	

}
