package com.student.domain;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import com.student.command.CreatedStudentCommand;
import com.student.command.UpdateStudentCommand;
import com.student.event.StudentCreatedEvent;
import com.student.event.StudentUpdateEvent;

import lombok.extern.slf4j.Slf4j;

@Aggregate
@Slf4j
public class Student {
	@AggregateIdentifier
	private String studentId;
	private String name;
	private int age;
	private String city;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@CommandHandler
	public Student(CreatedStudentCommand createdStudentCommand) {
		log.info("createdStudentCommand  {}");
		StudentCreatedEvent studentCreatedEvent=new StudentCreatedEvent(createdStudentCommand.getStudentId(),createdStudentCommand.getName(),createdStudentCommand.getAge(),createdStudentCommand.getCity());
		AggregateLifecycle.apply(studentCreatedEvent);
	}
	@EventSourcingHandler
	public void on(StudentCreatedEvent studentCreatedEvent) {
		log.info("student created event  {}");
		
		this.studentId=studentCreatedEvent.getStudentId();
		this.name=studentCreatedEvent.getName();
		this.age=studentCreatedEvent.getAge();
		this.city=studentCreatedEvent.getCity();
	}
	
	@CommandHandler
	public void handler(UpdateStudentCommand updateStudentCommand) {
		
		log.info("UpdateStudentCommand  {} ");
		
		StudentUpdateEvent studentUpdateEvent=new StudentUpdateEvent(updateStudentCommand.getStudentId(),updateStudentCommand.getName(),updateStudentCommand.getAge(),updateStudentCommand.getCity());
		AggregateLifecycle.apply(studentUpdateEvent);
		
	}
	
	
	@EventSourcingHandler
	public void on(StudentUpdateEvent studentUpdateEvent) {
		log.info("StudentUpdateEvent {}");
		this.name=studentUpdateEvent.getName();
		this.age=studentUpdateEvent.getAge();
		this.city=studentUpdateEvent.getCity();
	}
	
	

}
