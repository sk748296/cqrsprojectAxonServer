package com.student.event;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StudentUpdateEvent {
	
	
	private String studentId;
	private String name;
	private int age;
	private String city;
	public StudentUpdateEvent(String studentId, String name, int age, String city) {
		
		this.studentId = studentId;
		this.name = name;
		this.age = age;
		this.city = city;
	}
	
	
	

}
