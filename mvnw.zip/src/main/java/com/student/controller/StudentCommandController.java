package com.student.controller;

import java.util.UUID;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.command.CreatedStudentCommand;
import com.student.command.UpdateStudentCommand;
import com.student.dto.StudentDTO;

@RestController
@RequestMapping("/students")
public class StudentCommandController {
	@Autowired
	private CommandGateway commandGateway;
	
	@PostMapping
	public ResponseEntity<String> create(@RequestBody StudentDTO studentDTO) {
		String studentId= UUID.randomUUID().toString();
		CreatedStudentCommand createdStudentCommand=new CreatedStudentCommand(studentId,studentDTO.getName(),studentDTO.getAge(),studentDTO.getCity());
		commandGateway.send(createdStudentCommand);
		return ResponseEntity.ok("Student is Created"+studentId);
		
	}
	@PutMapping("/{studentId}")
	public ResponseEntity<String> update(@PathVariable String studentId,@RequestBody StudentDTO studentDTO){
		UpdateStudentCommand updateStudentCommand=new UpdateStudentCommand(studentId,studentDTO.getName(),studentDTO.getAge(),studentDTO.getCity());
		commandGateway.send(updateStudentCommand);
		return ResponseEntity.ok("student is updated");
	}

}
